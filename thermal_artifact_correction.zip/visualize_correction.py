"""
visualize_correction.py — 보고서용 보정 전/후 시각화 생성기
===========================================================
[단계 1.5] 광학 왜곡 보정 모듈의 보정 효과를 시각적으로 입증하기 위한
단독 실행 스크립트.

기능:
  ① 단계별 보정 시각화 (4-panel)    — FPN→Vignetting→Narcissus 누적 효과
  ② 보정 전/후 단순 비교 (2-panel)  — 발표 슬라이드용 깔끔한 비교
  ③ 반경 방향 프로파일               — 보정 효과의 정량적 입증

사용법:
  1) 단일 CSV 파일 시각화 (가장 일반적):
       python visualize_correction.py "C:\\path\\to\\sample.csv"

  2) 출력 폴더 지정:
       python visualize_correction.py "sample.csv" --out "C:\\report_figs"

  3) 4-패널 단계별 시각화까지 함께 생성:
       python visualize_correction.py "sample.csv" --steps
"""

import os
import sys
import argparse
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.font_manager as _fm

# ── 한글 폰트 설정 ───────────────────────────────────────────────────────────
def _setup_korean_font():
    paths = [
        "/usr/share/fonts/truetype/nanum/NanumGothic.ttf",
        "C:/Windows/Fonts/malgun.ttf",
        "/Library/Fonts/AppleGothic.ttf",
    ]
    for p in paths:
        if os.path.exists(p):
            try:
                _fm.fontManager.addfont(p)
            except Exception:
                pass
    # 사용 가능한 한글 폰트를 자동 선택
    for cand in ("NanumGothic", "Malgun Gothic", "AppleGothic"):
        if any(cand in f.name for f in _fm.fontManager.ttflist):
            plt.rcParams["font.family"] = cand
            break
    plt.rcParams["axes.unicode_minus"] = False

_setup_korean_font()

# 같은 폴더의 모듈 임포트
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from thermal_artifact_correction import (
    ThermalPreprocessor, FPNCorrector, VignettingCorrector, NarcissusCorrector
)


# ============================================================
# 입력 로드
# ============================================================

def load_csv(csv_path: str) -> np.ndarray:
    """FLIR Tools/Ignite Export CSV → 절대온도 행렬 [°C]."""
    # 헤더 자동 감지 (0~10 행 시도)
    for skip in range(11):
        try:
            arr = np.genfromtxt(
                csv_path, delimiter=",", skip_header=skip,
                dtype=np.float64, invalid_raise=False, encoding="utf-8"
            )
            if arr.ndim == 2 and arr.shape[0] >= 4 and arr.shape[1] >= 4:
                if np.isnan(arr).mean() < 0.5:
                    return arr
        except Exception:
            continue
    raise ValueError(f"CSV 로드 실패: {csv_path}")


# ============================================================
# 시각화 1: 보정 전/후 단순 비교 (2-panel, 발표용)
# ============================================================

def plot_before_after(T_raw, T_clean, save_path):
    """발표/보고서용 깔끔한 2패널 비교."""
    fig, axes = plt.subplots(1, 2, figsize=(13, 5))
    vmin = min(T_raw.min(), T_clean.min())
    vmax = max(T_raw.max(), T_clean.max())

    im0 = axes[0].imshow(T_raw, cmap="inferno", vmin=vmin, vmax=vmax, aspect="equal")
    axes[0].set_title("(a) 보정 전 (Raw)", fontsize=13)
    axes[0].set_xlabel("픽셀 열")
    axes[0].set_ylabel("픽셀 행")
    plt.colorbar(im0, ax=axes[0], shrink=0.85, label="온도 [°C]")

    im1 = axes[1].imshow(T_clean, cmap="inferno", vmin=vmin, vmax=vmax, aspect="equal")
    axes[1].set_title("(b) 보정 후 (FPN→Vignetting→Narcissus)", fontsize=13)
    axes[1].set_xlabel("픽셀 열")
    axes[1].set_ylabel("픽셀 행")
    plt.colorbar(im1, ax=axes[1], shrink=0.85, label="온도 [°C]")

    fig.suptitle("열화상 광학 왜곡 보정 결과", fontsize=14, fontweight="bold")
    plt.tight_layout(rect=[0, 0, 1, 0.96])
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    return save_path


# ============================================================
# 시각화 2: 단계별 누적 효과 (4-panel, 보고서 본문용)
# ============================================================

def plot_step_by_step(T_raw, save_path):
    """
    FPN → Vignetting → Narcissus 각 단계의 누적 효과를 4패널로 시각화.
    각 단계 보정기를 개별 호출하여 중간 결과를 캡처.
    """
    H, W = T_raw.shape

    # 각 단계를 개별 적용 (ThermalPreprocessor 내부 보정기 직접 활용)
    fpn = FPNCorrector(H, W)
    vig = VignettingCorrector(H, W)
    nar = NarcissusCorrector(H, W)

    T_after_fpn = fpn.correct(T_raw.copy())
    T_after_vig = vig.correct(T_after_fpn.copy())
    T_after_nar = nar.correct(T_after_vig.copy())

    fig, axes = plt.subplots(2, 2, figsize=(13, 11))
    vmin = min(T_raw.min(), T_after_nar.min())
    vmax = max(T_raw.max(), T_after_nar.max())

    panels = [
        (T_raw,        "(a) 원본 (Raw)"),
        (T_after_fpn,  "(b) FPN 제거 후"),
        (T_after_vig,  "(c) Vignetting 제거 후"),
        (T_after_nar,  "(d) Narcissus 제거 후 (최종)"),
    ]
    for ax, (data, title) in zip(axes.flat, panels):
        im = ax.imshow(data, cmap="inferno", vmin=vmin, vmax=vmax, aspect="equal")
        ax.set_title(title, fontsize=12)
        ax.set_xlabel("픽셀 열")
        ax.set_ylabel("픽셀 행")
        plt.colorbar(im, ax=ax, shrink=0.85, label="온도 [°C]")

    fig.suptitle("열화상 광학 왜곡 보정 단계별 누적 효과",
                 fontsize=14, fontweight="bold")
    plt.tight_layout(rect=[0, 0, 1, 0.96])
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    return save_path


# ============================================================
# 시각화 3: 반경 방향 프로파일 (정량적 입증용)
# ============================================================

def _radial_map(H, W):
    cy, cx = (H - 1) / 2.0, (W - 1) / 2.0
    y, x = np.mgrid[0:H, 0:W]
    return np.sqrt(((x - cx) / max(cx, 1)) ** 2 + ((y - cy) / max(cy, 1)) ** 2)


def plot_radial_profile(T_raw, T_clean, save_path):
    """
    반경 방향 온도 프로파일 비교 — 보정 효과의 정량적 입증.
    비네팅·나르키소스가 반경 의존 왜곡이므로 가장 명확하게 보임.
    """
    H, W = T_raw.shape
    r_map = _radial_map(H, W)
    r_flat = r_map.ravel()
    n_bins = 30
    edges = np.linspace(0, r_flat.max(), n_bins + 1)

    rc, T_raw_med, T_clean_med = [], [], []
    T_raw_std, T_clean_std = [], []
    for i in range(n_bins):
        mask = (r_flat >= edges[i]) & (r_flat < edges[i + 1])
        if mask.sum() >= 4:
            rc.append((edges[i] + edges[i + 1]) / 2)
            T_raw_med.append(np.median(T_raw.ravel()[mask]))
            T_clean_med.append(np.median(T_clean.ravel()[mask]))
            T_raw_std.append(np.std(T_raw.ravel()[mask]))
            T_clean_std.append(np.std(T_clean.ravel()[mask]))

    rc = np.array(rc)
    T_raw_med = np.array(T_raw_med)
    T_clean_med = np.array(T_clean_med)

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(rc, T_raw_med, "r-o", ms=6, lw=2, label="보정 전 (Raw)")
    ax.fill_between(rc, T_raw_med - T_raw_std, T_raw_med + T_raw_std,
                     color="red", alpha=0.15)
    ax.plot(rc, T_clean_med, "b-s", ms=6, lw=2, label="보정 후 (Corrected)")
    ax.fill_between(rc, T_clean_med - T_clean_std, T_clean_med + T_clean_std,
                     color="blue", alpha=0.15)

    ax.set_xlabel("정규화 반경 r  (중심=0, 코너≈√2)", fontsize=12)
    ax.set_ylabel("픽셀 온도 [°C]  (중앙값 ± 표준편차)", fontsize=12)
    ax.set_title("반경 방향 온도 프로파일 — 비네팅·나르키소스 제거 효과",
                 fontsize=13, fontweight="bold")
    ax.legend(fontsize=11, loc="best")
    ax.grid(True, alpha=0.3)

    # 보정 효과 정량 지표 표시
    var_raw = float(np.std(T_raw_med - T_raw_med.mean()))
    var_clean = float(np.std(T_clean_med - T_clean_med.mean()))
    improvement = (1 - var_clean / max(var_raw, 1e-9)) * 100
    info = (f"반경별 중앙값 분산:\n"
            f"  보정 전: {var_raw:.3f} °C\n"
            f"  보정 후: {var_clean:.3f} °C\n"
            f"  개선율: {improvement:.1f}%")
    ax.text(0.02, 0.98, info, transform=ax.transAxes,
            fontsize=10, verticalalignment="top",
            bbox=dict(boxstyle="round", facecolor="lightyellow", alpha=0.85))

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    return save_path


# ============================================================
# 메인
# ============================================================

def main(csv_path: str, out_dir: str = "./figures", do_steps: bool = False):
    if not os.path.isfile(csv_path):
        raise FileNotFoundError(f"CSV 파일 없음: {csv_path}")

    os.makedirs(out_dir, exist_ok=True)
    stem = os.path.splitext(os.path.basename(csv_path))[0]

    print(f"입력 : {csv_path}")
    print(f"출력 : {out_dir}\n")

    # 1) CSV → 절대온도 행렬
    T_raw = load_csv(csv_path)
    H, W = T_raw.shape
    print(f"[1] 행렬 크기: {W}×{H}")
    print(f"    범위    : {T_raw.min():.2f} ~ {T_raw.max():.2f} °C")

    # 2) 보정 실행
    prep = ThermalPreprocessor(H, W)
    T_clean = prep.correct(T_raw)
    print(f"\n[2] 보정 완료")
    print(prep.correction_summary())
    print(f"    보정 후 범위: {T_clean.min():.2f} ~ {T_clean.max():.2f} °C")

    # 3) 시각화 — 2패널 단순 비교 (보고서 표지/요약용)
    p1 = os.path.join(out_dir, f"{stem}_before_after.png")
    plot_before_after(T_raw, T_clean, p1)
    print(f"\n[3] 보정 전/후 비교: {p1}")

    # 4) 시각화 — 반경 방향 프로파일 (정량적 입증)
    p2 = os.path.join(out_dir, f"{stem}_radial_profile.png")
    plot_radial_profile(T_raw, T_clean, p2)
    print(f"[4] 반경 방향 프로파일: {p2}")

    # 5) 시각화 — 단계별 4패널 (보고서 본문용, 선택)
    if do_steps:
        p3 = os.path.join(out_dir, f"{stem}_step_by_step.png")
        plot_step_by_step(T_raw, p3)
        print(f"[5] 단계별 누적 시각화: {p3}")

    # 6) 빌트인 4패널 시각화 (제거된 왜곡 성분 포함)
    p4 = os.path.join(out_dir, f"{stem}_correction_full.png")
    prep.visualize_correction(T_raw, T_clean, save_path=p4)
    print(f"[6] 보정 분석 4패널: {p4}")

    print(f"\n✅ 보고서용 시각화 {3 + int(do_steps)}장 생성 완료")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="열화상 보정 전/후 시각화 — 보고서/발표용",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
예시:
  python visualize_correction.py "sample.csv"
  python visualize_correction.py "sample.csv" --out "./report_figs"
  python visualize_correction.py "sample.csv" --steps  (4패널 단계별 추가)
""",
    )
    parser.add_argument("csv_path", help="입력 CSV (절대온도 행렬)")
    parser.add_argument("--out", default="./figures",
                         help="출력 폴더 (기본: ./figures)")
    parser.add_argument("--steps", action="store_true",
                         help="4패널 단계별 누적 효과 시각화 추가 생성")
    args = parser.parse_args()

    main(args.csv_path, out_dir=args.out, do_steps=args.steps)